//Nabeelah Maryam
//23I-8201
#include <iostream>
#include <cstring>
#include <cctype>

// Function to calculate the length of the string
int calculateLength(const char* str) {
    return std::strlen(str);
}

// Function to count the number of words in a string
int countWords(const char* str) {
    int wordCount = 0;
    bool inWord = false;

    for (int i = 0; str[i] != '\0'; i++) {
        if (std::isspace(str[i])) {
            inWord = false;
        } else if (!inWord) {
            wordCount++;
            inWord = true;
        }
    }

    return wordCount;
}

// Function to check if a string is palindrome or not
bool isPalindrome(const char* str) {
    int length = std::strlen(str);
    for (int i = 0; i < length / 2; i++) {
        if (str[i] != str[length - i - 1]) {
            return false;
        }
    }
    return true;
}

// Function to find a word within the array and display its starting position
int findWord(const char* str, const char* word) {
    const char* found = std::strstr(str, word);
    if (found) {
        return found - str;
    } else {
        return -1;
    }
}

// Function to convert a string to lowercase
void toLowercase(char* str) {
    for (int i = 0; str[i] != '\0'; i++) {
        str[i] = std::tolower(str[i]);
    }
}

// Function to convert a string to uppercase
void toUppercase(char* str) {
    for (int i = 0; str[i] != '\0'; i++) {
        str[i] = std::toupper(str[i]);
    }
}

int main() {
    const int MAX_LENGTH = 100;
    char str[MAX_LENGTH];

    std::cout << "Enter a string: ";
    std::cin.getline(str, MAX_LENGTH);

    int choice;
    do {
        std::cout << "\nMenu:\n";
        std::cout << "1. Calculate length of string\n";
        std::cout << "2. Count the number of words in a string\n";
        std::cout << "3. Check if a string is palindrome or not\n";
        std::cout << "4. Find a word within the array and display its starting position\n";
        std::cout << "5. Convert the string to lowercase\n";
        std::cout << "6. Convert the string to uppercase\n";
        std::cout << "7. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        std::cin.ignore(); // Clear the newline character

        switch (choice) {
            case 1:
                std::cout << "Length of the string: " << calculateLength(str) << std::endl;
                break;
            case 2:
                std::cout << "Number of words in the string: " << countWords(str) << std::endl;
                break;
            case 3:
                if (isPalindrome(str)) {
                    std::cout << "The string is a palindrome." << std::endl;
                } else {
                    std::cout << "The string is not a palindrome." << std::endl;
                }
                break;
            case 4:
                char searchWord[MAX_LENGTH];
                std::cout << "Enter the word to search for: ";
                std::cin.getline(searchWord, MAX_LENGTH);

                int position = findWord(str, searchWord);
                if (position != -1) {
                    std::cout << "Word found at position " << position << std::endl;
                } else {
                    std::cout << "Word not found in the string." << std::endl;
                }
                break;
            case 5:
                toLowercase(str);
                std::cout << "String converted to lowercase: " << str << std::endl;
                break;
            case 6:
                toUppercase(str);
                std::cout << "String converted to uppercase: " << str << std::endl;
                break;
            case 7:
                std::cout << "Exiting the program." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please enter a valid option." << std::endl;
        }
    } while (choice != 7);

    return 0;
}
