//Nabeelah Maryam
//23I-8201
#include <iostream>
#include <vector>
#include <climits>

int main() {
    int n;
    std::cout << "Enter the number of elements in the array: ";
    std::cin >> n;

    if (n < 2) {
        std::cout << "At least two elements are required for comparison." << std::endl;
        return 1;
    }

    std::vector<int> arr(n);

    std::cout << "Enter the elements of the array:" << std::endl;
    for (int i = 0; i < n; i++) {
        std::cout << "Element " << i + 1 << ": ";
        std::cin >> arr[i];
    }

    int minDiff = INT_MAX;  // Initialize to a large value
    int maxDiff = INT_MIN;  // Initialize to a small value
    int pair1, pair2;

    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            int diff = std::abs(arr[i] - arr[j]);

            if (diff < minDiff) {
                minDiff = diff;
                pair1 = arr[i];
                pair2 = arr[j];
            }

            if (diff > maxDiff) {
                maxDiff = diff;
                pair1 = arr[i];
                pair2 = arr[j];
            }
        }
    }

    std::cout << "Pair with Minimum Difference: " << pair1 << " and " << pair2 << " with difference " << minDiff << std::endl;
    std::cout << "Pair with Maximum Difference: " << pair1 << " and " << pair2 << " with difference " << maxDiff << std::endl;

    return 0;
}
