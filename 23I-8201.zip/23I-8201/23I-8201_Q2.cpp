//Nabeelah Maryam
//23I-8201
#include <iostream>
#include <iomanip>

int main() {
    double gallons, totalBill;
    
    // Input the number of gallons from the user
    std::cout << "Enter the number of gallons: ";
    std::cin >> gallons;

    // Calculate the total bill based on the given conditions
    if (gallons <= 100) {
        totalBill = gallons * 0.45;
    } else if (gallons <= 350) {
        totalBill = 100 * 0.45 + (gallons - 100) * 0.85;
    } else if (gallons <= 600) {
        totalBill = 100 * 0.45 + 250 * 0.85 + (gallons - 350) * 1.45;
    } else {
        totalBill = 100 * 0.45 + 250 * 0.85 + 250 * 1.45 + (gallons - 600) * 2.60;
    }

    // Add the 14% service charge
    totalBill *= 1.14;

    // Display the total bill with 2 decimal places
    std::cout << "Total bill: $" << std::fixed << std::setprecision(2) << totalBill << std::endl;

    return 0;
}
