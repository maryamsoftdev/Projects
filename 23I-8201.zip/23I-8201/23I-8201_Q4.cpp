//Nabeelah Maryam
//23I-8201
#include <iostream>

int main() {
    // Display the menu
    std::cout << "Welcome to Your Burger Shop!" << std::endl;
    std::cout << "-------- Menu --------" << std::endl;
    std::cout << "1. Choose your bun" << std::endl;
    std::cout << "   a. Sesame bun ($0.72)" << std::endl;
    std::cout << "   b. Whole wheat bun ($0.72)" << std::endl;
    std::cout << "   c. Pretzel bun ($0.72)" << std::endl;
    std::cout << "2. Make it cheesy (Maximum 2)" << std::endl;
    std::cout << "   a. American cheese ($0.50)" << std::endl;
    std::cout << "   b. Swiss cheese ($0.50)" << std::endl;
    std::cout << "   c. Cheddar cheese ($0.50)" << std::endl;
    std::cout << "3. Turn up the taste (Required)" << std::endl;
    std::cout << "   a. Bacon ($1.20)" << std::endl;
    std::cout << "   b. Mushrooms ($1.20)" << std::endl;
    std::cout << "   c. Onions ($1.20)" << std::endl;
    std::cout << "4. Fresh'N it up (Maximum 3, press 0 to skip)" << std::endl;
    std::cout << "   a. Lettuce ($0.20)" << std::endl;
    std::cout << "   b. Tomato ($0.20)" << std::endl;
    std::cout << "   c. Pickles ($0.20)" << std::endl;
    std::cout << "5. Get saucy (Maximum 3, press 0 to skip)" << std::endl;
    std::cout << "   a. Ketchup ($0.30)" << std::endl;
    std::cout << "   b. Mustard ($0.30)" << std::endl;
    std::cout << "   c. Mayo ($0.30)" << std::endl;

    // Initialize variables for cost
    double bunCost = 0.0;
    double cheeseCost = 0.0;
    double tasteCost = 0.0;
    double freshCost = 0.0;
    double sauceCost = 0.0;

    // Step 1: Choose your bun
    char bunChoice;
    std::cout << "Step 1: Choose your bun (a/b/c): ";
    std::cin >> bunChoice;

    switch (bunChoice) {
        case 'a':
            bunCost = 0.72;
            break;
        case 'b':
            bunCost = 0.72;
            break;
        case 'c':
            bunCost = 0.72;
            break;
        default:
            std::cout << "Invalid choice. Default bun (Sesame bun) selected." << std::endl;
            bunCost = 0.72;
            break;
    }

    // Step 2: Make it cheesy (Maximum 2)
    char cheeseChoice;
    int cheeseCount = 0;
    while (cheeseCount < 2) {
        std::cout << "Step 2: Make it cheesy (a/b/c, 0 to skip): ";
        std::cin >> cheeseChoice;

        if (cheeseChoice == '0') {
            break;
        }

        switch (cheeseChoice) {
            case 'a':
            case 'b':
            case 'c':
                cheeseCost += 0.50;
                cheeseCount++;
                break;
            default:
                std::cout << "Invalid choice. Please choose a valid cheese or press 0 to skip." << std::endl;
                break;
        }
    }

    // Step 3: Turn up the taste (Required)
    char tasteChoice;
    std::cout << "Step 3: Turn up the taste (a/b/c): ";
    std::cin >> tasteChoice;

    switch (tasteChoice) {
        case 'a':
            tasteCost = 1.20;
            break;
        case 'b':
            tasteCost = 1.20;
            break;
        case 'c':
            tasteCost = 1.20;
            break;
        default:
            std::cout << "Invalid choice. Please choose a valid taste option." << std::endl;
            return 1; // Exit program
    }

    // Step 4: Fresh'N it up (Maximum 3, press 0 to skip)
    char freshChoice;
    int freshCount = 0;
    while (freshCount < 3) {
        std::cout << "Step 4: Fresh'N it up (a/b/c, 0 to skip): ";
        std::cin >> freshChoice;

        if (freshChoice == '0') {
            break;
        }

        switch (freshChoice) {
            case 'a':
            case 'b':
            case 'c':
                freshCost += 0.20;
                freshCount++;
                break;
            default:
                std::cout << "Invalid choice. Please choose a valid fresh option or press 0 to skip." << std::endl;
                break;
        }
    }

    // Step 5: Get saucy (Maximum 3, press 0 to skip)
    char sauceChoice;
    int sauceCount = 0;
    while (sauceCount < 3) {
        std::cout << "Step 5: Get saucy (a/b/c, 0 to skip): ";
        std::cin >> sauceChoice;

        if (sauceChoice == '0') {
            break;
        }

        switch (sauceChoice) {
            case 'a':
            case 'b':
            case 'c':
                sauceCost += 0.30;
                sauceCount++;
                break;
            default:
                std::cout << "Invalid choice. Please choose a valid sauce option or press 0 to skip." << std::endl;
                break;
        }
    }

    // Calculate the total cost
    double totalCost = bunCost + cheeseCost + tasteCost + freshCost + sauceCost;

    // Display the total cost
    std::cout << "Your burger's total cost is: $" << totalCost << std::endl;

    return 0;
}