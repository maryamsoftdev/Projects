//Nabeelah Maryam
//23I-8201
#include <iostream>
#include <cstdlib>
#include <ctime>

// Function to initialize the game board
void initializeBoard(char board[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            board[i][j] = ' ';
        }
    }
}

// Function to display the game board
void displayBoard(const char board[3][3]) {
    std::cout << "-------------" << std::endl;
    for (int i = 0; i < 3; i++) {
        std::cout << "| ";
        for (int j = 0; j < 3; j++) {
            std::cout << board[i][j] << " | ";
        }
        std::cout << std::endl << "-------------" << std::endl;
    }
}

// Function to check if the game is over
bool isGameOver(const char board[3][3]) {
    // Check rows and columns for a win
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ')
            return true;
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != ' ')
            return true;
    }

    // Check diagonals for a win
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ')
        return true;
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != ' ')
        return true;

    // Check for a draw (no empty spaces left)
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == ' ')
                return false;
        }
    }
    return true;
}

// Function for the user's turn
void userTurn(char board[3][3]) {
    int row, col;
    do {
        std::cout << "Enter row (0-2) and column (0-2) for your move (e.g., 1 1): ";
        std::cin >> row >> col;
    } while (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ');
    board[row][col] = 'X';
}

// Function for the computer's turn (random move)
void computerTurn(char board[3][3]) {
    int row, col;
    do {
        row = rand() % 3;
        col = rand() % 3;
    } while (board[row][col] != ' ');
    board[row][col] = 'O';
}

int main() {
    srand(static_cast<unsigned>(time(nullptr)));

    char board[3][3];
    initializeBoard(board);
    displayBoard(board);

    bool userTurnFlag = true; // true: User's turn, false: Computer's turn

    while (!isGameOver(board)) {
        if (userTurnFlag) {
            userTurn(board);
        } else {
            computerTurn(board);
        }

        displayBoard(board);
        userTurnFlag = !userTurnFlag;
    }

    if (isGameOver(board)) {
        if (userTurnFlag) {
            std::cout << "Computer wins! You lose." << std::endl;
        } else {
            std::cout << "Congratulations! You win." << std::endl;
        }
    } else {
        std::cout << "It's a draw!" << std::endl;
    }

    return 0;
}