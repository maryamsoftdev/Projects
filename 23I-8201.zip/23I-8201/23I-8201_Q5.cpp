//Nabeelah Maryam
//23I-8201

#include <iostream>

int main() {
    int n = 6;  // Number of rows

    for (int i = 0; i < n; ++i) {
        // Print spaces before "!"
        for (int j = 0; j < i; ++j) {
            std::cout << " ";
        }

        // Print "!" symbols
        for (int k = 0; k < n - i; ++k) {
            std::cout << "!";
        }

        // Print spaces between the two sets of "!" symbols
        for (int l = 0; l < i; ++l) {
            std::cout << " /";
        }

        std::cout << std::endl;
    }

    return 0;
}