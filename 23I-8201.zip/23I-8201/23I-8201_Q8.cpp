//Nabeelah Maryam
//23I-8201

#include <iostream>

int main() {
    int r1, c1, r2, c2;

    // Input dimensions of the first matrix
    std::cout << "Enter the number of rows for the first matrix: ";
    std::cin >> r1;
    std::cout << "Enter the number of columns for the first matrix: ";
    std::cin >> c1;

    // Input dimensions of the second matrix
    std::cout << "Enter the number of rows for the second matrix: ";
    std::cin >> r2;
    std::cout << "Enter the number of columns for the second matrix: ";
    std::cin >> c2;

    // Check if multiplication is possible
    if (c1 != r2) {
        std::cout << "Matrix multiplication is not possible. Columns of the first matrix must be equal to rows of the second matrix." << std::endl;
        return 1;
    }

    // Initialize matrices
    int matrix1[r1][c1], matrix2[r2][c2], result[r1][c2];

    // Input elements of the first matrix
    std::cout << "Enter elements of the first matrix:" << std::endl;
    for (int i = 0; i < r1; ++i) {
        for (int j = 0; j < c1; ++j) {
            std::cout << "Enter element at row " << i + 1 << ", column " << j + 1 << ": ";
            std::cin >> matrix1[i][j];
        }
    }

    // Input elements of the second matrix
    std::cout << "Enter elements of the second matrix:" << std::endl;
    for (int i = 0; i < r2; ++i) {
        for (int j = 0; j < c2; ++j) {
            std::cout << "Enter element at row " << i + 1 << ", column " << j + 1 << ": ";
            std::cin >> matrix2[i][j];
        }
    }

    // Initialize the result matrix with zeros
    for (int i = 0; i < r1; ++i) {
        for (int j = 0; j < c2; ++j) {
            result[i][j] = 0;
        }
    }

    // Perform matrix multiplication
    for (int i = 0; i < r1; ++i) {
        for (int j = 0; j < c2; ++j) {
            for (int k = 0; k < c1; ++k) {
                result[i][j] += matrix1[i][k] * matrix2[k][j];
            }
        }
    }

    // Display the result matrix
    std::cout << "Resultant Matrix:" << std::endl;
    for (int i = 0; i < r1; ++i) {
        for (int j = 0; j < c2; ++j) {
            std::cout << result[i][j] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}
