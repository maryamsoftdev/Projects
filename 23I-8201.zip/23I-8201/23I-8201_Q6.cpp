//Nabeelah Maryam
//23I-8201
#include <iostream>
#include <cctype>  // For isalpha and tolower functions

int main() {
    // Initialize variables to count letters and vowels
    int totalLetters = 0;
    int totalVowels = 0;
    int letterCounts[26] = {0};  // Array to count individual letters (a to z)

    std::cout << "Enter a sentence: ";
    
    // Read input character by character
    char ch;
    while (std::cin.get(ch) && ch != '\n') {
        // Convert the character to lowercase
        char lowerCh = tolower(ch);
        
        // Check if it's a letter
        if (isalpha(lowerCh)) {
            totalLetters++;
            
            // Check if it's a vowel (a, e, i, o, u)
            if (lowerCh == 'a' || lowerCh == 'e' || lowerCh == 'i' || lowerCh == 'o' || lowerCh == 'u') {
                totalVowels++;
            }
            
            // Count individual letters (a to z)
            letterCounts[lowerCh - 'a']++;
        }
    }
    
    // Output results
    std::cout << "Total Number of Vowels: " << totalVowels << std::endl;
    std::cout << "Total Number of letters: " << totalLetters << std::endl;
    
    // Output individual letter counts
    for (char letter = 'a'; letter <= 'z'; letter++) {
        std::cout << "Total Number of " << letter << "'s: " << letterCounts[letter - 'a'] << std::endl;
    }

    return 0;
}