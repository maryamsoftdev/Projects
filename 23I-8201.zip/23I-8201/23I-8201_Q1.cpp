//Nabeelah Maryam
//23I-8201

#include <iostream>

int main() {
    int num1, num2, num3;

    // Input three non-negative integers from the user
    std::cout << "Input the first number: ";
    std::cin >> num1;
    
    std::cout << "Input the second number: ";
    std::cin >> num2;
    
    std::cout << "Input the third number: ";
    std::cin >> num3;

    // Checking for integer rightmost digit
    int last_digit_num1 = num1 % 10;
    int last_digit_num2 = num2 % 10;
    int last_digit_num3 = num3 % 10;

    // Check if any two of the digits are the same
    bool result = (last_digit_num1 == last_digit_num2) || (last_digit_num1 == last_digit_num3) || (last_digit_num2 == last_digit_num3);

    // Print the result
    std::cout << "The result is: " << std::boolalpha << result << std::endl;

    return 0;
}