//Nabeelah Maryam
//23I-8201
#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
    srand(static_cast<unsigned>(time(nullptr)));

    const int numRows = 4;
    const int numCols = 4;
    const int totalSquares = numRows * numCols;

    int round = 1;
    int victoryCount = 0;
    int warningCount = 0;
    int prevVictoryNumbers[5] = {-1, -1, -1, -1, -1};

    std::cout << "Welcome to the guessing game!" << std::endl;

    while (round <= 5) {
        int square1, square2;
        bool isValidInput = false;

        std::cout << "Round " << round << std::endl;

        // Generate two random squares
        square1 = rand() % totalSquares + 1;
        square2 = rand() % totalSquares + 1;

        // Check if the squares are the same
        bool areEqual = (square1 == square2);

        // Check if the squares have already been won in previous rounds
        bool isDuplicate = false;
        for (int i = 0; i < victoryCount; ++i) {
            if (square1 == prevVictoryNumbers[i] || square2 == prevVictoryNumbers[i]) {
                isDuplicate = true;
                break;
            }
        }

        if (!isDuplicate) {
            if (areEqual) {
                std::cout << "Congratulations! You guessed correctly in Round " << round << std::endl;
                prevVictoryNumbers[victoryCount] = square1;
                victoryCount++;
                round++;
            } else {
                std::cout << "Sorry, the squares are not equal. Try again." << std::endl;
                round++;
            }
        } else {
            warningCount++;
            if (warningCount >= 4) {
                std::cout << "WARNING 4 **END OF PROGRAM**" << std::endl;
                break;
            }
            std::cout << "WARNING " << warningCount << " - You have entered the same squares as a previous victory. Try again." << std::endl;
        }
    }

    if (victoryCount >= 3) {
        std::cout << "Congratulations! You won at least 3 rounds. You win the game!" << std::endl;
    } else {
        std::cout << "Sorry, you did not win enough rounds. Better luck next time!" << std::endl;
    }

    return 0;
}