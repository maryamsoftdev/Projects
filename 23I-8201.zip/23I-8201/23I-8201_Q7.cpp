//Nabeelah Maryam
//23I-8201
#include <iostream>
#include <cstdlib>
#include <ctime>

int generateRandomNumber(int min, int max) {
    return min + rand() % (max - min + 1);
}

int main() {
    srand(static_cast<unsigned>(time(nullptr)));

    char choice;
    do {
        std::cout << "Welcome to Guessing games" << std::endl;
        std::cout << "1. Play Higher or Lower" << std::endl;
        std::cout << "2. Play paper - scissors - rock" << std::endl;
        std::cout << "3. Guess the numbers" << std::endl;
        std::cout << "4. Quit" << std::endl;
        std::cout << "Enter your choice (1 - 4): ";
        std::cin >> choice;

        switch (choice) {
            case '1': {
                int firstNumber = generateRandomNumber(1, 20);
                int secondNumber = generateRandomNumber(1, 20);

                std::cout << "First number: " << firstNumber << std::endl;
                std::cout << "Enter H for Higher or L for Lower: ";
                char userGuess;
                std::cin >> userGuess;

                if ((userGuess == 'H' && secondNumber > firstNumber) || (userGuess == 'L' && secondNumber < firstNumber)) {
                    std::cout << "You win!" << std::endl;
                } else {
                    std::cout << "You lose!" << std::endl;
                }

                break;
            }
            case '2': {
                int computerChoice = generateRandomNumber(1, 3);
                char userChoice;

                std::cout << "Enter P for paper, S for scissors, or R for rock: ";
                std::cin >> userChoice;

                if ((userChoice == 'P' && computerChoice == 1) ||
                    (userChoice == 'S' && computerChoice == 2) ||
                    (userChoice == 'R' && computerChoice == 3)) {
                    std::cout << "You win!" << std::endl;
                } else {
                    std::cout << "You lose!" << std::endl;
                }

                break;
            }
            case '3': {
                int generatedNumbers[3];
                int userGuesses[3];

                for (int i = 0; i < 3; ++i) {
                    generatedNumbers[i] = generateRandomNumber(0, 9);
                }

                std::cout << "Enter your three guesses (0 - 9): ";
                for (int i = 0; i < 3; ++i) {
                    std::cin >> userGuesses[i];
                }

                int matches = 0;
                bool exactOrder = true;

                for (int i = 0; i < 3; ++i) {
                    if (userGuesses[i] == generatedNumbers[i]) {
                        matches++;
                    } else {
                        exactOrder = false;
                    }
                }

                if (matches == 3) {
                    std::cout << "You win: Three matching in exact order!" << std::endl;
                } else if (matches == 0) {
                    std::cout << "You lose: No matches at all." << std::endl;
                } else if (exactOrder) {
                    std::cout << "You win: Three matching, not in order!" << std::endl;
                } else {
                    std::cout << "You win: " << matches << " matching number(s)!" << std::endl;
                }

                break;
            }
            case '4':
                std::cout << "Thanks for playing. Goodbye!" << std::endl;
                break;
            default:
                std::cout << "Invalid input. Please enter a valid choice (1 - 4)." << std::endl;
                break;
        }
    } while (choice != '4');

    return 0;
}
