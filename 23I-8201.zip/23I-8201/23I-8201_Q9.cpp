//Nabeelah Maryam
//23I-8201
#include <iostream>
void arrangeArray(char myArray[], int size) {
    int countA = 0, countB = 0, countC = 0;

    // Count the occurrences of 'a', 'b', and 'c' in the array
    for (int i = 0; i < size; i++) {
        if (myArray[i] == 'a') {
            countA++;
        } else if (myArray[i] == 'b') {
            countB++;
        } else if (myArray[i] == 'c') {
            countC++;
        }
    }

    // Fill the array with 'a's, 'b's, and 'c's according to the counts
    int index = 0;

    // Add 'a's
    for (int i = 0; i < countA; i++) {
        myArray[index] = 'a';
        index++;
    }

    // Add 'b's
    for (int i = 0; i < countB; i++) {
        myArray[index] = 'b';
        index++;
    }

    // Add 'c's
    for (int i = 0; i < countC; i++) {
        myArray[index] = 'c';
        index++;
    }
}

int main() {
    char myArray[] = {'b', 'c', 'a', 'a', 'b', 'c', 'a', 'c', 'b', 'a'};
    int size = sizeof(myArray) / sizeof(myArray[0]);

    std::cout << "Original Array: ";
    for (int i = 0; i < size; i++) {
        std::cout << myArray[i] << " ";
    }

    arrangeArray(myArray, size);

    std::cout << "\nArranged Array: ";
    for (int i = 0; i < size; i++) {
        std::cout << myArray[i] << " ";
    }

    return 0;
}
