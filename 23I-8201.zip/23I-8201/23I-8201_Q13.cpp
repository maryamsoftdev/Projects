#include <iostream>

const int MAX_SIZE = 100;

// Function to count occurrences of x in arr[]
int Count(const int arr[], int size, int x) {
    int count = 0;
    for (int i = 0; i < size; i++) {
        if (arr[i] == x) {
            count++;
        }
    }
    return count;
}

// Function to partition the array around the first element x
void Partition(int arr[], int size) {
    if (size <= 1) {
        return; // Nothing to partition
    }

    int x = arr[0]; // Pivot element
    int left = 1;   // Index of the leftmost element greater than x

    for (int right = 1; right < size; right++) {
        if (arr[right] < x) {
            // Swap arr[left] and arr[right]
            int temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            left++;
        }
    }

    // Swap arr[0] and arr[left-1]
    int temp = arr[0];
    arr[0] = arr[left - 1];
    arr[left - 1] = temp;
}

// Function to calculate frequencies of elements and display them
void Duplicates(const int arr[], int size) {
    for (int i = 0; i < size; i++) {
        int count = Count(arr, size, arr[i]);
        std::cout << "Element " << arr[i] << " occurs " << count << " times." << std::endl;
    }
}

// Function to perform circular replacement in the array
void Circular(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        int next1 = (i + 1) % size;
        int next2 = (i + 2) % size;
        arr[i] = arr[next1] + arr[next2];
    }
}

// Function to search for an element in the array and return its index (or a negative number if not found)
int Search(const int arr[], int size, int element) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == element) {
            return i;
        }
    }
    return -1; // Element not found
}

int main() {
    int arr[MAX_SIZE];
    int size;

    std::cout << "Enter the size of the array (up to " << MAX_SIZE << "): ";
    std::cin >> size;

    if (size <= 0 || size > MAX_SIZE) {
        std::cout << "Invalid array size. Exiting." << std::endl;
        return 1;
    }

    std::cout << "Enter " << size << " elements for the array:" << std::endl;
    for (int i = 0; i < size; i++) {
        std::cin >> arr[i];
    }

    int choice;
    int searchResult = -1; // Initialize with a default value

    do {
        std::cout << "\nMenu:\n";
        std::cout << "1. Count occurrences of an element\n";
        std::cout << "2. Partition the array\n";
        std::cout << "3. Calculate and display frequencies of elements\n";
        std::cout << "4. Perform circular replacement\n";
        std::cout << "5. Search for an element\n";
        std::cout << "6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                int countElement;
                std::cout << "Enter the element to count: ";
                std::cin >> countElement;
                std::cout << "Count: " << Count(arr, size, countElement) << std::endl;
                break;
            case 2:
                Partition(arr, size);
                std::cout << "Array partitioned." << std::endl;
                break;
            case 3:
                Duplicates(arr, size);
                break;
            case 4:
                Circular(arr, size);
                std::cout << "Circular replacement done." << std::endl;
                break;
            case 5:
                int searchElement;
                std::cout << "Enter the element to search for: ";
                std::cin >> searchElement;
                searchResult = Search(arr, size, searchElement);
                if (searchResult >= 0) {
                    std::cout << "Element found at index " << searchResult << std::endl;
                } else {
                    std::cout << "Element not found in the array." << std::endl;
                }
                break;
            case 6:
                std::cout << "Exiting the program." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please enter a valid option." << std::endl;
        }
    } while (choice != 6);

    return 0;
}
